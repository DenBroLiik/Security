<?php
namespace app\modules;

use std, gui, framework, app;


class MainModule extends AbstractModule
{

    /**
     * @event construct 
     */
    function doConstruct(ScriptEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->showPreloader('100');
		$this->hidePreloader();

        
    }

}

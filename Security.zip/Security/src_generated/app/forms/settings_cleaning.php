<?php
namespace app\forms;

use std, gui, framework, app;
use action\Element; 
use php\io\File; 


class settings_cleaning extends AbstractForm
{

    /**
     * @event button3.click-Left 
     */
    function doButton3ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setValue($this->button3, 'Выкл');

        
    }

    /**
     * @event button3.click-Right 
     */
    function doButton3ClickRight(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setValue($this->button3, 'Вкл');

        
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->showForm('garbage_size');

        
    }

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('settings', true, true);

        
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2


		if (File::of('100MB.DBL')->isFile())
			Element::setText($this->button4, '100 MB');

		if (File::of('300MB.DBL')->isFile())
			Element::setText($this->button4, '300 MB');

		if (File::of('500MB.DBL')->isFile())
			Element::setText($this->button4, '500 MB');

		if (File::of('1GB.DBL')->isFile())
			Element::setText($this->button4, '1,00 GB');

        
    }






}

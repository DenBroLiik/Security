<?php
namespace app\forms;

use std, gui, framework, app;
use action\Element; 
use action\Animation; 
use php\io\File; 


class settings extends AbstractForm
{

    /**
     * @event link.click-Left 
     */
    function doLinkClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		browse('https://discord.gg/9kKmuNHj36');

        
    }

    /**
     * @event button11.click-Left 
     */
    function doButton11ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('MainForm', true, true);

        
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setValue($this, 'Security-settings');

        
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('settings_cleaning');

        
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeIn($this, 2000, function () use ($e, $event) {

			if (File::of('notification_widget.bat')->isFile())
				Element::setText($this->button9, 'Вкл');
		});

        
    }


}

<?php
namespace app\forms;

use std, gui, framework, app;
use php\io\File; 
use php\gui\UXDialog; 
use action\Element; 
use action\Animation; 


class MainForm extends AbstractForm
{

    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $e = null)
    {
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('settings', true, true);

    
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setValue($this, 'Security-menu');

        
    }

    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {
        
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        
        if (fs::exists('C:\Security\System_Service_Plugin.bat') == true)
        {
        $this->loadForm('Game_Turbo', true, true);
        } else UXDialog::show('У вас нет плагина системной службы', 'ERROR');
            
    }

    /**
     * @event button6.click-Left 
     */
    function doButton6ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('PowerMode', true, true);

		if (!File::of('C:\Security\powermode_Max_high.bat')->isFile())
			$this->form('PowerMode')->button4->hide();

		if (File::of('C:\Security\powermode_Max_high.bat')->isFile())
			$this->form('PowerMode')->button4->show();

        
    }

    /**
     * @event button9.click-Left 
     */
    function doButton9ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('root_device', true, true);

        
    }

    /**
     * @event rect5.construct 
     */
    function doRect5Construct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeIn($this, 2000, function () use ($e, $event) {
		});

        
    }

    /**
     * @event button5.click-Left 
     */
    function doButton5ClickLeft(UXMouseEvent $e = null)
    {    
        
    }


}

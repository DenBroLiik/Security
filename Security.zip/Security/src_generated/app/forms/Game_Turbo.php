<?php
namespace app\forms;

use std, gui, framework, app;
use php\io\File; 
use action\Element; 


class Game_Turbo extends AbstractForm
{

    /**
     * @event imageAlt.construct 
     */
    function doImageAltConstruct(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2


		if (File::of('com.mojang')->isDirectory())
			Element::setValue($this->button3, 'Minecraft PE');

        
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->showFormAndWait('Game_Turbo_Tab');
		$this->form('Game_Turbo_Tab')->randomMove->enable();

        
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        execute('C:\Security/Mine.mcpack');
        $this->toast('Успешно ускорено');
    }

    /**
     * @event button5.click-Left 
     */
    function doButton5ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('Game_Turbo_features', true, true);

        
    }

    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('MainForm', true, true);

        
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2


		if (File::of('C:\Security\GPUTURNER_SWITCH.true')->isFile())
			$this->button5->show();

		if (!File::of('C:\Security\GPUTURNER_SWITCH.true')->isFile())
			$this->button5->hide();

        
    }


}

<?php
namespace app\forms;

use std, gui, framework, app;


class Game_Turbo_Tab extends AbstractForm
{


    /**
     * @event keyDown-Shift+Tab 
     */
    function doKeyDownShiftTab(UXKeyEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->minimizeForm('Game_Turbo_Tab');

        
    }


}

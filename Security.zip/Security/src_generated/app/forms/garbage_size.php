<?php
namespace app\forms;

use std, gui, framework, app;
use action\Element; 


class garbage_size extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setValue($this->form('settings_cleaning')->button4, '100 GB');
		app()->hideForm('garbage_size');
		execute('gleaning_100MB.bat', true);

        
    }

    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setValue($this->form('settings_cleaning')->button4, '300 GB');
		app()->hideForm('garbage_size');
		execute('gleaning_300MB', true);

        
    }

    /**
     * @event click-Left 
     */
    function doClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setValue($this->form('settings_cleaning')->button4, '500 GB');
		app()->hideForm('garbage_size');

        
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setValue($this->form('settings_cleaning')->button4, '1,00 GB');
		app()->hideForm('garbage_size');
		execute('gleaning_1,00GB', true);

        
    }

    /**
     * @event button3.click-Left 
     */
    function doButton3ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setValue($this->form('settings_cleaning')->button4, '500 MB');
		app()->hideForm('garbage_size');
		execute('gleaning_500MB', true);

        
    }

}

<?php
namespace app\forms;

use std, gui, framework, app;


class settings extends AbstractForm
{

    /**
     * @event link.click-Left 
     */
    function doLinkClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button11.click-Left 
     */
    function doButton11ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        
    }


}

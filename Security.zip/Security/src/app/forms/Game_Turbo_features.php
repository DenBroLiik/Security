<?php
namespace app\forms;

use std, gui, framework, app;
use action\Element; 


class Game_Turbo_features extends AbstractForm
{

    /**
     * @event button7.click-Left 
     */
    function doButton7ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button8.click-Left 
     */
    function doButton8ClickLeft(UXMouseEvent $e = null)
    {
        
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        execute('C:\Security/FPS_30.bat');
        Element::setText($this->button8, '30 FPS');
    }

    /**
     * @event button8.click-2x 
     */
    function doButton8Click2x(UXMouseEvent $e = null)
    {
        
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        execute('C:\Security/FPS_60.bat');
        Element::setText($this->button8, '60 FPS');
    }




}

<?php
namespace app\forms;

use std, gui, framework, app;


class root_telephone extends AbstractForm
{

}
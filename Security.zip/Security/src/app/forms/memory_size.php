<?php
namespace app\forms;

use std, gui, framework, app;


class memory_size extends AbstractForm
{

}
<?php
namespace app\forms;

use std, gui, framework, app;
use php\io\File; 
use php\gui\UXDialog; 


class MainForm extends AbstractForm
{

    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $e = null)
    {
    
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        
    }

    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {
        
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        
        if (fs::exists('C:\Security\System_Service_Plugin.bat') == true)
        {
        $this->loadForm('Game_Turbo', true, true);
        } else UXDialog::show('У вас нет плагина системной службы', 'ERROR');
            
    }

    /**
     * @event button6.click-Left 
     */
    function doButton6ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button9.click-Left 
     */
    function doButton9ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect5.construct 
     */
    function doRect5Construct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button5.click-Left 
     */
    function doButton5ClickLeft(UXMouseEvent $e = null)
    {    
        
    }


}
